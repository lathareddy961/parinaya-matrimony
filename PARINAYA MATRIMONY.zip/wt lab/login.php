<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
body{
	background-image: url('/wedding.jpeg');
	background-size:100%;
}
.text{
	font-weight: bold;
}
.border{
	border-color:red;
}
.heading{
	font-family: Arial;
}
.button{
	margin-left: 110px;
}
</style>
</head>
<body>
<p id="demo"></p>
<form action="login.php" method="POST" id="form" >
<div>
<h3 align="center" class="pt-3 heading">LOG IN</h3>
<div class="row">
<div class="col-md-4"></div>
<div class="col-md-4 pt-5">
<div class="card">
<div class="card-body">
<label for="mail" class="mt-2 form-label text-dark text">email:</label>
<input id="mail" type="email" name="ename" class="form-control">
<span id="merror"></span><br>
<label for="pwd" class="mt-2 form-label text-dark text">mobile:</label>
<input id="mobile" type="text" name="mobile" class="form-control">
<span id="perror"></span><br>
<?php
	ini_set('display_errors',1);
	ini_set('display_startup_errors',1);
	error_reporting(E_ALL);

	if(isset($_POST['btn'])){

	$email = $_POST['ename'];
	$mobile = $_POST['mobile'];

	include 'connection.php';
	
	$query="SELECT * FROM login";
	$check=mysqli_query($connect,$query);
	
	if(mysqli_num_rows($check)){
		$count = 0;
		while($row=mysqli_fetch_assoc($check)){
			if($row['EMAIL']==$email
			){
 				$count = 1;
			}
			else{
				$count = $count;
			}
		}
		if($count == 1){
			$query1="SELECT MOBILE from login WHERE EMAIL='$email';";
			$check1=mysqli_query($connect,$query1);
			$result1=mysqli_fetch_assoc($check1);
			if($result1['MOBILE']==$mobile){
				header("Location:5_bytes_home.html");
				exit;
			}
			else{
				echo "PASSWORD NOT CORRECT";
			}
		}
		else{
			echo "USER DOESN'T EXIST";
		}			
	}
}
?>
<button type="submit"  class="mt-2 btn btn-info text-dark button" name="btn" id="btn">submit</button>
</form>
</div>
</div>
</div>
</div>
</div>
</body>
</html>