<!DOCTYPE html>
<html>
    <head>
        <title>SIGNUP</title>
        <link href="bootstrap/css/bootsrap.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="mani.css">
    </head>
    <body style=" background-image: url('wedding6.jpg');">
        <div class="text">
            <?php
            ini_set("display_errors",1);
            ini_set("display_startup_errors",1);
            error_reporting(E_ALL);
            include 'connection.php';
            /*if($connect){
                echo "CONNECTION ESTABLISHED";
            }
            else{
            echo 'connection not established';
            }*/
            $name = $_POST['name'];
            $email = $_POST['email'];
            $mobile = $_POST['mobile'];
            $query = "INSERT INTO login VALUES('$name','$email','$mobile');";
            $check=mysqli_query($connect,$query);
            if($check)
            {
                echo "Account Created Successfully Go Back to login page !!";
            }
            else{
                echo "record not inserted successfully".mysqli_error($connect);
            }
            ?>
        </div>
        <a href="login.php"><button class="btn  button" type="submit">BACK</button></a>
    </body>
</html>
</html>